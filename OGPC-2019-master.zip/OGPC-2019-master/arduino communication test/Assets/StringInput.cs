﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;
using UnityEngine.UI;

public class StringInput : MonoBehaviour {

    SerialPort stream = new SerialPort("COM4", 9600);

    InputField input_1;

    // Use this for initialization
    void Start () {
        if (input_1.text != "")
        {
            stream.Open();
            stream.WriteLine(input_1.text);
            System.Threading.Thread.Sleep(1000);
            stream.Close();
        }
    }
	
	// Update is called once per frame
	void Update () {
     
	}
}

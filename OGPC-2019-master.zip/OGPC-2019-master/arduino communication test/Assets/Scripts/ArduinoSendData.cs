﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class ArduinoSendData : MonoBehaviour {

    SerialPort stream = new SerialPort("COM4", 9600);

    // Use this for initialization
    void Start () {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Opens the Serial Stream
        stream.Open();
        System.Threading.Thread.Sleep(1000);
        stream.WriteLine("45");
        System.Threading.Thread.Sleep(1000);
        stream.Close();
        Debug.Log("Button Pressed");
    }
}

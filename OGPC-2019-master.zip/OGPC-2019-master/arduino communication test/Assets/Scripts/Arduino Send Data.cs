﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class ArduinoSendData : MonoBehaviour {

    SerialPort stream = new SerialPort("COM4", 9600);

    // Use this for initialization
    void Start () {
        //Opens the Serial Stream
        stream.Open();

        
    }

    // Update is called once per frame
    void Update()
    {
        stream.WriteLine("1");
    }
}

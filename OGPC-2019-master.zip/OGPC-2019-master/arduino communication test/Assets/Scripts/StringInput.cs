﻿using UnityEngine;
using System.IO.Ports;
using UnityEngine.UI;

public class StringInput : MonoBehaviour {


    SerialPort stream = new SerialPort("COM4", 9600);

    public InputField input_1;

    // Use this for initialization
    void Start () {
        
    }
	
	// Update is called once per frame
	public void send_data (string newtext) {
        if (newtext !=  "")
        {
            string positon = newtext;
            stream.Open();
            stream.WriteLine(positon);
            System.Threading.Thread.Sleep(15);
            stream.Close();
        }
    }
}

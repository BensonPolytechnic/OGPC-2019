﻿using UnityEngine;
using System.IO.Ports;

public class AudrinoCommunication : MonoBehaviour
{
    //Set the port and baud rate
    public SerialPort stream = new SerialPort("COM4", 9600);


    void Start()
    {
        //Opens the Serial Stream
        stream.Open();
        System.Threading.Thread.Sleep(1000);
        stream.WriteLine("180");
        System.Threading.Thread.Sleep(1000);
        stream.WriteLine("0");
        stream.Close();
    }

    void Update()
    {
        //Read information from Audrino
    }

    void OnGUI()
    {
        //Display the new values

    }

}

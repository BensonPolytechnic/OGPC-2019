﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO.Ports;

public class Arduino_Interface : MonoBehaviour {
    SerialPort serial_1 = new SerialPort("COM4", 115200);

    bool servo_mode = true;


    public void Update()
    {


       if (!servo_mode)
       {
            if (Input.GetKeyDown(KeyCode.J))
            {
                servo_mode = true;
            }
       }

        else if (servo_mode)
        {
            if (Input.GetKeyDown(KeyCode.J))
            {
                servo_mode = false;
            }
        }

         if (servo_mode)
        {
            send_xroll();
        }
    }

    public void send_xroll()
    {
        float dial_position = 90f;
        float vert_pos = transform.position.y;
        float change = vert_pos / 9f;
        if (change < -87f)
        {
            change = -87f;
        }
        else if (change > 89f)
        {
            change = 89f;
        }

        dial_position = dial_position - change;
        dial_position = (int)dial_position;
        serial_1.Open();
        serial_1.Write(dial_position.ToString());
        System.Threading.Thread.Sleep(1);
        serial_1.Close();
        Debug.Log(dial_position.ToString());
    }
}

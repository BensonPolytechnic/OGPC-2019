﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Timers;
using System.Threading;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public GameObject[] Points;
    public Camera Camera;
    public Transform Plane;
    private Vector3[] oldPosition;
    public Vector3 EulerAngles;
    static PauseMenu planeScript;

    int scalePos = 0;
    double planeScaling = 2;
    float distance;
    public float lockPos = 0;
    Boolean paused = false;
    IEnumerator Timer;

    void Awake()
    {
        //DontDestroyOnLoad(transform.gameObject);
    }

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //var Camera = transform.localPosition;
        //Input.location.Start();
        StartCoroutine(Delay());
    }

    IEnumerator Delay()
    {
        EulerAngles = Camera.transform.rotation.eulerAngles;
        //SceneManager.LoadScene(sceneBuildIndex: 3);
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (paused == false)
            {
                for (int x = 0; x <= 25; x++)
                {
                    int scaleX = x * 15;
                    Camera.transform.Translate(Vector3.up * Time.deltaTime * scaleX);
                    Camera.transform.LookAt(Plane);
                    yield return new WaitForSecondsRealtime(1 / 64);
                }
                //SceneManager.LoadSceneAsync(1);
                paused = true;
            }
            if (paused == true)
            {
                //SceneManager.LoadSceneAsync(2);
                for (int y = 0; y <= 25; y++)
                {
                    int scaleY = y * 15;
                    Camera.transform.Translate(Vector3.down * Time.deltaTime * scaleY);
                    Camera.transform.LookAt(Plane);
                    yield return new WaitForSecondsRealtime(1 / 64);
                }
                paused = false;
            }
        }
    }
}

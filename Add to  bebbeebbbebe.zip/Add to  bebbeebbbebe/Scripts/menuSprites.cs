﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class menuSprites : MonoBehaviour
{

    public GameObject mapBackground;
    public GameObject planeIcon;
    public GameObject mapUI;
    public Camera mainCamera;
    public GameObject Plane;

    // Use this for initialization
    void Start()
    {
        mapBackground.transform.position = new Vector3(0, 0, 2);
        planeIcon.transform.position = new Vector3(0, 0, 0);
        mapUI.transform.position = new Vector3(0, 0, 1);
    }

    // Update is called once per frame
    void Update()
    {
        /*for (int x = 0; x <= 4; x++)
        {
            planeIcon.transform.position = new Vector3(Plane.transform.position.x, Plane.transform.position.y, 0);
        }
	}
*/
    }
}